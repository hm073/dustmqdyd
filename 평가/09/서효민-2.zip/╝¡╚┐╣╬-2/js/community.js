document.addEventListener("DOMContentLoaded", () => {

    const btn = document.getElementById("plus");

    btn.addEventListener("click", () => {
        alert("게시글을 작성하시겠습니까?");
    });

}); //end